import { MessageEmbed } from "discord.js";
import { ICommand } from "wokcommands";

export default {
    category: 'General',
    name: 'List',
    description: 'Sends a list of commands available.',
    slash: 'both',
    guildOnly: true,
    testOnly: true,
    
    callback: ({ message, text }) => {
        const embed = new MessageEmbed()
        .setTitle('List of commands available:')
        .setDescription('Prefix: ; or / ')
        .setColor(0xB7CFED)
        .addFields([
            {
            name: 'Section 1: General commands',
            value: 'List - sends a list of commands'
            },
            {
                name: 'Section 2: Admin commands',
                value: 'Warn add - adds a warning to the user \n Warn remove - removes a warning from the user \n Warn list - lists all warnings of the user \n Kick|Ban - Kicks or bans the user' 
            },
            {
                name: 'Section 3: Owner commands',
                value: 'Eval - developing \n Slash - Owner Commands'
            }
    ])
        return embed
    },
} as ICommand