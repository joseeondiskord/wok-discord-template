import { ICommand } from "wokcommands";

export default {
    category: 'Configuration',
    name: 'Status',
    description: 'Sets the bot status',

    minArgs: 1,
    expectedArgs: '<status>',

    slash: 'both',
    testOnly: true,
    ownerOnly: true,
    hidden: true,

    callback: ({ client, text }) => {
        client.user?.setPresence({
            status: 'idle',
            activities: [ 
                {
                    name: text,
                },
            ],
        })

        return 'Status updated.'
    },
}as ICommand