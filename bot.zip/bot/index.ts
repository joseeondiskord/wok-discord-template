import DiscordJS, { Intents, Interaction } from 'discord.js'
import WOKCommands from 'wokcommands'
import mongoose from 'mongoose'
import path from 'path'
import 'dotenv/config'

import testSchema from './test-schema'

const client = new DiscordJS.Client({
    intents: [
      Intents.FLAGS.GUILDS,
      Intents.FLAGS.GUILD_MESSAGES
    ],
  })

client.on('ready', async () => {


    new WOKCommands(client, {
        commandsDir: path.join(__dirname, 'commands'),
        typeScript: true,
        testServers: ['943802411997335552'],
       mongoUri: process.env.MONGO_URI,
       botOwners: ['664058041339084810', '609185539739877386']
    })


    .setDefaultPrefix(';') // Set your prefix here
    .setColor(0xB7CFED)
})

  client.login(process.env.TOKEN)